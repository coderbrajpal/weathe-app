const express = require("express");
const axios = require("axios");
require(`dotenv`).config();

const app = express();
const PORT = process.env.PORT || 3000;
const Weather_api_key = `4c6f3115fe6f063b476c8afd29f929d0`;





app.get('/',(req,res)=>{
    res.send("welcome to the weather api")
});

app.get('/weather',async(req,res) =>{
    const city = req.query.city;
    if (!city){
        return res.status(400).send({error:"please provide a city name"})

    }
    try{
        const response = await axios.get(`http://api.weatherstack.com/current`,{
            params:{
                access_key : Weather_api_key,
                query:city
            }
        });
        const data = response.data;
        
        res.json({
            loction:data.location.name,
            tempreture:data.current.tempreture,
            weather_description : data.current.weather_description[0]
        });


    }catch (error){
        console.log(`Error faching data :`, error.message);
        res.status(500).send({error:`Failed to fetch weather data`})

    }
});
app.get('/weather/city=:city', (req, res) => {
    const city = req.params.city;
    // Logic to get weather for the city
    res.send(`Weather data for ${city}`);
  });

  axios.get('http://api.example.com/weather')
  .then(response => {
    if (response && response.data) {
      console.log(response.data.name);
    } else {
      console.error('No data found in the response');
    }
  })
  .catch(error => {
    console.error('Error fetching data:', error);
  });

  

// start the server 
app.listen(PORT,()=>{
    console.log(`server is running on http//localhost:${PORT}`);
});